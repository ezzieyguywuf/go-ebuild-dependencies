Gazelle functionality
=====================

Tests that ensure rules_go still works with Gazelle.

gazelle_test
------------
Checks that Gazelle can be run in a test workspace.

