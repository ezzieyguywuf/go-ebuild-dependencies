// +build !good

package main

var Does Not = Compile
