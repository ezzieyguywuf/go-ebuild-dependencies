int half(int x) { return x/2; }

