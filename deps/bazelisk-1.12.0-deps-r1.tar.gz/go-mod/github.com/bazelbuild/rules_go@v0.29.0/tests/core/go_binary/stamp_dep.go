package stamp_dep

var (
	DepSelf = "redacted"
	DepBin  = "redacted"
)
