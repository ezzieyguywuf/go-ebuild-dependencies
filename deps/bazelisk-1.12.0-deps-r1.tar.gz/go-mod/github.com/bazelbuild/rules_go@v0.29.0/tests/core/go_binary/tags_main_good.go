// +build good

package main

import _ "tags_lib"

func main() {
}
