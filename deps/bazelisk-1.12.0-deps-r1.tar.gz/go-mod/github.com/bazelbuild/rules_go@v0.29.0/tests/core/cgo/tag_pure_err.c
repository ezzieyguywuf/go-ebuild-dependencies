#error should not be compiled
