Go rules examples
===================

This contains examples of how to apply the go rules to common problems.

Contents
--------

.. Child list start

* `Executable name <executable_name/README.rst>`_

.. Child list end

