package go_lib

import "C"
