package foo

// Other architectures are not supported for this test. This function just
// returns what the assembly function was supposed to return.
func foo() int32 {
	return 42
}
