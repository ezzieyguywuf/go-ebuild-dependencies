package build_constraints

var suffix = "linux"
